import pandas as pd
from textblob import TextBlob
import matplotlib.pyplot as plt

# Load tweets from CSV
try:
    df = pd.read_csv('tweets.csv')
except FileNotFoundError:
    print("Error: tweets.csv not found.")
    exit()

# Function to analyze sentiment with neutral threshold
def get_sentiment(text):
    analysis = TextBlob(text)
    polarity = analysis.sentiment.polarity
    
    # Set threshold for neutral
    if polarity >= 0.05:
        return 'Positive'
    elif polarity <= -0.05:
        return 'Negative'
    else:
        return 'Neutral'

# Apply sentiment analysis
df['Sentiment'] = df['tweet'].apply(get_sentiment)

# Display results
print("\nSentiment Analysis Results:\n")
print(df)

# Count sentiment values
sentiment_counts = df['Sentiment'].value_counts()

# Display Value Count
print("\nSentiment Summary:\n")
for sentiment, count in df['Sentiment'].value_counts().items():
    print(f"{sentiment}: {count}")
